#pragma once


#include "resultcodes.h"
#include "input_mode.h"
#include <stddef.h>


namespace bigfish
{


enum INPUT
{
    INPUT_1,
    INPUT_2,
    INPUT_3,
    INPUT_4
};


RESULT          writeInputMode(INPUT input, INPUT_MODE mode);


RESULT          writeInputOnThreshold(INPUT input, unsigned int threshold);
RESULT          writeInputOffThreshold(INPUT input, unsigned int threshold);


int             readInput(INPUT input, RESULT *result = NULL);


int             getLastInputValue(INPUT input, RESULT *result = NULL);


unsigned int    getLastInputTime(INPUT input, RESULT *result = NULL);


RESULT          writeInputPullup(INPUT input, int on);


int             getLastInputPullupState(INPUT input, RESULT *result = NULL);


RESULT          writeInputShunt(INPUT input, int on);


int             getLastInputShuntState(INPUT input, RESULT *result = NULL);


RESULT          writeInputCounters(INPUT input, unsigned int pulses, unsigned int time);


}
