#pragma once


#include "resultcodes.h"


namespace bigfish
{


const char * getResultCodeString(RESULT result);


}
