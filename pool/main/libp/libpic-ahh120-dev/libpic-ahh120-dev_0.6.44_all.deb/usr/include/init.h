#pragma once


#include "resultcodes.h"


namespace bigfish
{


RESULT openApi();


RESULT closeApi();


RESULT idleApi();


}
