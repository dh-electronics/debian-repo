#pragma once


#include "resultcodes.h"


namespace bigfish
{


enum DAC
{
    DAC_1,
    DAC_2
};


RESULT writeDac(enum DAC dac, int value);


}
