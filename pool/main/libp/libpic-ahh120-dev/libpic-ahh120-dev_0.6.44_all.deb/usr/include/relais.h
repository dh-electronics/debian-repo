#pragma once


#include "resultcodes.h"


namespace bigfish
{


enum RELAY
{
    RELAY_1 = 0,
    RELAY_2 = 1
};


RESULT writeRelay(RELAY relay, int on);


}
