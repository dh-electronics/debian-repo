#ifndef INPUTMODE_H
#define INPUTMODE_H


#ifdef __cplusplus
namespace bigfish
{
#endif


enum INPUT_MODE {
    INPUT_MODE_ANALOG   = 0,
    INPUT_MODE_COUNTER  = 1,
    INPUT_MODE_PT1000   = 2,
    INPUT_MODE_OFF      = 3
};


#ifdef __cplusplus
}
#endif


#endif // INPUTMODE_H
