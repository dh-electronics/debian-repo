#pragma once


#include "resultcodes.h"


namespace bigfish
{


RESULT writeEeprom(unsigned short *data, unsigned short offset, unsigned char wordCount);


}
