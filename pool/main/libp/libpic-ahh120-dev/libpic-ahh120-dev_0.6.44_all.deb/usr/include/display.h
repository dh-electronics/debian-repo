#pragma once


#include "resultcodes.h"


namespace bigfish
{


struct Bitmap;
struct FT_Bitmap_;


RESULT displayEnable(int on);


RESULT displaySetContrast(int value);


RESULT displayFill(bool white = false);


RESULT displayFillRect(int x, int y, int w, int h, bool white = true);


RESULT displayDrawRect(int x, int y, int w, int h, bool white = true);


RESULT displayInvertRect(int x, int y, int w, int h);


RESULT displayBitmap(int x, int y, const Bitmap &bmp);
RESULT displayBitmap(int x, int y, const struct FT_Bitmap_ &bmp);


RESULT displayFlush();


RESULT displaySwap();
RESULT displayWriteSplash();

}
