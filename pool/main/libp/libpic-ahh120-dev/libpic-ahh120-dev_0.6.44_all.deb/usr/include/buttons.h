#pragma once


#include "resultcodes.h"
#include <stddef.h>


namespace bigfish
{


enum BUTTON
{
    BUTTON_UP = 0,
    BUTTON_DN = 1,
    BUTTON_MID = 2,
    BUTTON_ESC = 3,
    BUTTON_OK = 4
};


typedef void buttonsCallback(BUTTON button, bool pressed);

RESULT setButtonsCallback(buttonsCallback *callback);

RESULT handleButtons();

bool    getButtonState(BUTTON button, enum RESULT *res = NULL);


}
