#pragma once


#include "resultcodes.h"
#include <stddef.h>


#define API_VERSION     0x0006
#define API_REVISION    44


namespace bigfish
{


unsigned int getCrcErrorCounter(RESULT *result = NULL);


unsigned int getResponseErrorCounter(RESULT *result = NULL);


unsigned int getBusyCounter(RESULT *result = NULL);


unsigned int getTimeoutsCounter(RESULT *result = NULL);


unsigned int getResetsCounter(RESULT *result = NULL);


void resetStats(RESULT *result = NULL);


unsigned int getApiVersion(RESULT *result = NULL);


unsigned int getPicVersion(RESULT *result = NULL);


unsigned int getHwRevision(RESULT *result = NULL);


}
