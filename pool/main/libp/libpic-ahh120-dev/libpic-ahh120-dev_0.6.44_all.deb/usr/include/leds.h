#pragma once


#include "resultcodes.h"
#include <stddef.h>


namespace bigfish
{


enum LED
{
    LED_RS232_A, LED_RS232_B,
    LED_CAN,
    LED_READY, LED_STATUS, LED_ALARM, LED_ONLINE
};


RESULT writeLed(enum LED led, int on);


int getLedState(enum LED led, RESULT *result = NULL);


}
