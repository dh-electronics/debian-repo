#! /bin/sh
# format_emmc
# Author:  CN
# Version: 1.0

if test $# -ne 1; then
	echo
	echo -n "Syntax: "
	echo -n ${0##*/}
	echo    " </dev/volume_name>"
	echo
	exit 1
else
	if [ -b $1 ]; then
	# fdisk: o n p 1 <LF> +114M n p 2 <LF> <LF> w
	echo "o\nn\np\n1\n\n+114M\nn\np\n2\n\n\nw\n" | fdisk $1
	mkfs.ext3 $1p1
	mkfs.ext3 $1p2
	else
		echo "Error: Volume $1 not found"
	fi
fi

